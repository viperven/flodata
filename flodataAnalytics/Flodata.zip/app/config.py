# app/config.py

class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'Rj112233#'
    MYSQL_DB = 'parcel_management'
    MYSQL_CURSORCLASS = 'DictCursor'
    SECRET_KEY = 'your_secret_key'
